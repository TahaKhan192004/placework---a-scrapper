export const FIELDS = ['name','address','phone','website','rating','reviews_count','category','hours','description','maps_url','maps_status','maps_error','website_status','website_error','website_error_code','emails','website_phones','website_addresses','facebook','linkedin','instagram','youtube','threads','decision_makers','revenue','pages_scraped'];
export const running = job => job && ['maps','websites'].includes(job.stage);
export function validate(query, limit) {
  if (typeof query !== 'string' || !query.trim() || query.length > 300) throw Error('Enter a search query of 1–300 characters.');
  if (!Number.isInteger(limit) || limit < 1 || limit > 200) throw Error('Choose a whole number from 1 to 200.');
  return {query:query.trim(), limit};
}
export function placeKey(url) {
  const decoded = decodeURIComponent(url);
  return decoded.match(/!1s([^!]+)/)?.[1] || url.split('?')[0];
}
export function websiteKey(url) {
  const parsed = new URL(url);
  if (!['https:','http:'].includes(parsed.protocol)) throw Error('Unsupported website URL');
  for (const key of [...parsed.searchParams.keys()]) if (/^(utm_|gclid|fbclid)/i.test(key)) parsed.searchParams.delete(key);
  parsed.hash = '';
  return parsed.href;
}
export function csv(rows) {
  const cell = (value, key) => {
    if (Array.isArray(value)) value = value.some(v => typeof v === 'object') ? JSON.stringify(value) : value.join('; ');
    else if (value && typeof value === 'object') value = JSON.stringify(value);
    let s = String(value ?? '');
    const phone = ['phone','website_phones'].includes(key) && /^[+\d\s().;x-]+$/.test(s);
    if (/^[\s]*[=+@-]/.test(s) && !phone) s = "'" + s;
    return '"' + s.replaceAll('"','""') + '"';
  };
  return '\uFEFF' + [FIELDS.map(k => cell(k,k)).join(','), ...rows.map(row => FIELDS.map(k => cell(row[k],k)).join(','))].join('\r\n') + '\r\n';
}
export function mergeContact(target, result) {
  for (const key of ['emails','website_phones','website_addresses','facebook','linkedin','instagram','youtube','threads','revenue','pages_scraped']) {
    target[key] = [...new Set([...(target[key] || []), ...(result[key] || [])])].slice(0,100);
  }
  const people = [...(target.decision_makers || []), ...(result.decision_makers || [])];
  target.decision_makers = [...new Map(people.map(p => [JSON.stringify(p),p])).values()].slice(0,20);
  return target;
}
export function hasContacts(row) {
  return ['emails','website_phones','website_addresses','facebook','linkedin','instagram','youtube','threads','decision_makers'].some(k => row[k]?.length);
}
