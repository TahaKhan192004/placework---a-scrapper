import {validate,placeKey,websiteKey,mergeContact,hasContacts,running} from './core.js';
import {networkIssue} from './network.js';

const ALARM='placework-checkpoint';
let chain=Promise.resolve(), timer;
const serial=fn => {const next=chain.then(fn); chain=next.catch(()=>{}); return next;};
const load=async()=> (await chrome.storage.local.get('jobs')).jobs || [];
async function save(jobs) {
  await chrome.storage.local.set({jobs});
  const job=jobs[0];
  await chrome.action.setBadgeText({text:running(job) ? String(job.rows.length) : job?.stage==='paused' ? 'Ⅱ' : ''});
  await chrome.action.setBadgeBackgroundColor({color:'#ac4c2c'});
}
function kick(delay=1800) {
  clearTimeout(timer);
  timer=setTimeout(()=>serial(drive).catch(console.error),delay);
}
async function closeOwned(job) {
  const id=job.tabId; job.tabId=null; job.target=null;
  if (id != null) {try {await chrome.tabs.remove(id);} catch {}}
}
async function navigate(job, url, jobs, retry=false) {
  const previous=job.tabId;
  // A new document per target prevents the old Maps panel leaking into a row.
  const tab=await chrome.tabs.create({url:'about:blank',active:false});
  job.tabId=tab.id; job.target=url; job.navStarted=Date.now(); job.loadedAt=null;job.navError=null;job.domReadyAt=null;
  if(!retry)job.navAttempts=0;
  await chrome.tabs.update(tab.id,{autoDiscardable:false});
  await save(jobs);
  await chrome.tabs.update(tab.id,{url});
  if (previous != null) {try {await chrome.tabs.remove(previous);} catch {}}
  return false;
}
async function ready(job, url, jobs) {
  if (job.target!==url || job.tabId==null) return navigate(job,url,jobs);
  let tab;
  try {tab=await chrome.tabs.get(job.tabId);} catch {throw Error('The scraping tab was closed.');}
  if(job.navError)throw Error(job.navError);
  if (tab.url==='about:blank') {
    await chrome.tabs.update(job.tabId,{url});return false;
  }
  if (Date.now()-job.navStarted>60000) throw Error('net::ERR_TIMED_OUT');
  if (tab.status!=='complete' && !job.domReadyAt) return false;
  if (!job.loadedAt) {job.loadedAt=Date.now();await save(jobs);return false;}
  return Date.now()-job.loadedAt>=2500;
}
async function extract(job, method) {
  await chrome.scripting.executeScript({target:{tabId:job.tabId},files:['extractor.js']});
  const results=await chrome.scripting.executeScript({target:{tabId:job.tabId},func:name=>globalThis.PlaceworkExtractor[name](),args:[method]});
  return results[0]?.result || {error:'No page data returned.'};
}
async function finishSite(job) {
  const row=job.rows[job.index];
  const result=job.siteResult || {};
  result.website_status = hasContacts(result) ? 'success' : result.pages_scraped?.length ? 'no_contacts_found' : 'failed';
  result.website_error = (job.siteErrors || []).join(' | ');
  result.website_error_code = !result.pages_scraped?.length ? job.lastErrorCode || '' : '';
  Object.assign(row,result);
  if (row.website) job.siteCache[websiteKey(row.website)]=structuredClone(result);
  job.index++;job.processed=job.index;
  job.sitePages=null;job.siteResult=null;job.siteErrors=[];
  job.lastErrorCode=null;job.retryAt=null;
}
async function step(job,jobs) {
  if(job.retryAt) {
    if(Date.now()<job.retryAt)return;
    job.retryAt=null;
    await navigate(job,job.target,jobs,true);return;
  }
  if (job.phase==='discover') {
    const url='https://www.google.com/maps/search/'+encodeURIComponent(job.query);
    if (!await ready(job,url,jobs)) return;
    const found=await extract(job,'discover');
    if (found.blocked) {job.stage='paused';job.message='Google Maps needs your attention. Open the scraping tab, then Resume.';return;}
    if (found.error) throw Error(found.error);
    const before=job.urls.length;
    const keys=new Set(job.urls.map(placeKey));
    for (const link of found.links || []) {
      if (!keys.has(placeKey(link)) && job.urls.length<job.limit) {keys.add(placeKey(link));job.urls.push(link);}
    }
    if (found.single && !found.feed && !job.urls.length) job.urls=[found.url];
    job.stalled=job.urls.length===before ? job.stalled+1 : 0;
    job.scrolls++;
    job.message=`Found ${job.urls.length} unique places. Loading search results…`;
    // Each discovery read is a checkpoint, so service-worker restarts are harmless.
    if (job.urls.length>=job.limit || job.stalled>=5 || job.scrolls>=200 || (job.urls.length && !found.feed)) {
      if (!job.urls.length) throw Error('No places were returned. Try a more specific query or check the Maps tab.');
      job.phase='details';job.index=0;job.message=`Reading ${job.urls.length} unique places…`;
    }
    return;
  }
  if (job.phase==='details') {
    if (job.index>=job.urls.length) {job.stage='websites';job.phase='websites';job.index=0;job.processed=0;job.message='Collecting website contacts…';return;}
    const url=job.urls[job.index];
    if (!await ready(job,url,jobs)) return;
    const data=await extract(job,'place');
    if (data.blocked) {job.stage='paused';job.message='Google Maps needs your attention. Open the scraping tab, then Resume.';return;}
    if (data.waiting) return;
    if (!data.row?.name) throw Error(data.error || 'No business name found.');
    job.rows.push({...data.row,maps_url:url});job.index++;
    job.message=`Read ${job.index} of ${job.urls.length} places: ${data.row.name}`;
    return;
  }
  if (job.index>=job.rows.length) {
    const failed=job.rows.filter(r=>r.website_status==='failed').length;
    job.stage='complete';job.message=`Finished ${job.rows.length} unique places. ${job.rows.filter(r=>r.website_status==='success').length} websites enriched.${failed?` ${failed} failed to load; retry them without repeating Maps.`:''}`;
    await closeOwned(job);await chrome.alarms.clear(ALARM);return;
  }
  const row=job.rows[job.index];
  if(job.retryOnly && row.website_status!=='failed') {job.index++;job.processed=job.index;return;}
  if (row.maps_status!=='success' || !row.website) {
    row.website_status=row.maps_status==='success' ? 'no_website' : 'maps_failed';job.index++;job.processed=job.index;return;
  }
  let url;
  try {url=websiteKey(row.website);} catch {row.website_status='invalid_url';job.index++;job.processed=job.index;return;}
  if (job.siteCache[url]) {Object.assign(row,job.siteCache[url]);job.index++;job.processed=job.index;return;}
  if (!job.sitePages) {job.sitePages=[url];job.sitePage=0;job.siteResult={};job.siteErrors=[];job.lastErrorCode=null;}
  const target=job.sitePages[job.sitePage];
  job.message=`Enriching ${job.index+1} of ${job.rows.length}: ${row.name} (page ${job.sitePage+1}/${job.sitePages.length})`;
  if (!await ready(job,target,jobs)) return;
  const data=await extract(job,'contact');
  if (data.waiting) return;
  if (data.blocked || data.error) {
    job.siteErrors.push(`${target}: ${data.error || 'Access challenge; not bypassed.'}`);
  } else {
    mergeContact(job.siteResult,data.row);
    if (job.sitePage===0) {
      const origin=new URL(data.url).origin;
      job.sitePages=[target,...[...new Set((data.links || []).map(websiteKey))].filter(u=>u!==websiteKey(data.url) && u!==target && new URL(u).origin===origin)].slice(0,5);
    }
  }
  job.sitePage++;
  if (job.sitePage>=job.sitePages.length || data.blocked) await finishSite(job);
}
async function drive() {
  const jobs=await load(), job=jobs[0];
  if (!running(job)) return;
  try {await step(job,jobs);} catch (error) {
    const issue=networkIssue(error.message);
    if(job.phase==='websites' && job.target && issue.retryable && (job.navAttempts || 0)<2) {
      job.navAttempts=(job.navAttempts || 0)+1;
      job.retryAt=Date.now()+job.navAttempts*4000;
      job.message=`Connection failed. Retrying ${job.rows[job.index]?.name || 'website'} (${job.navAttempts}/2)…`;
      await save(jobs);kick();return;
    }
    if (job.phase==='discover') {job.stage='paused';job.message=error.message+' Resume to retry.';}
    else if (job.phase==='details') {
      const url=job.urls[job.index];
      job.rows.push({maps_url:url,maps_status:'failed',maps_error:error.message,name:decodeURIComponent(url.split('/place/')[1]?.split('/')[0] || '').replaceAll('+',' ')});
      job.index++;
    } else {
      job.siteErrors ||= [];job.siteErrors.push(`${issue.message} [${issue.code}]`);job.lastErrorCode=issue.code;
      if (job.sitePages && job.sitePage+1<job.sitePages.length) job.sitePage++;
      else await finishSite(job);
    }
  }
  await save(jobs);
  if (running(job)) kick();
}

async function command(message) {
  const jobs=await load(), job=jobs[0];
  if (message.type==='list') return {jobs:jobs.map(j=>({id:j.id,query:j.query,stage:j.stage,phase:j.phase,processed:j.processed,rows:j.rows,message:j.message}))};
  if (message.type==='start') {
    const input=validate(message.query,message.limit);
    if (running(job) || job?.stage==='paused') throw Error('Finish or stop the current run first.');
    const next={...input,id:crypto.randomUUID(),stage:'maps',phase:'discover',rows:[],urls:[],index:0,processed:0,stalled:0,scrolls:0,tabId:null,target:null,siteCache:{},message:'Opening an inactive Maps tab…'};
    await save([next,...jobs].slice(0,10));await chrome.alarms.create(ALARM,{periodInMinutes:0.5});kick(0);return {ok:true};
  }
  if(message.type==='retry-failed' && job?.id===message.id) {
    if(running(job) || job.stage==='paused')throw Error('Stop or finish the active run before retrying.');
    if(!job.rows.some(r=>r.website_status==='failed' && r.website))throw Error('There are no failed websites to retry.');
    await closeOwned(job);
    Object.assign(job,{stage:'websites',phase:'websites',index:0,processed:0,siteCache:{},sitePages:null,siteResult:null,siteErrors:[],retryAt:null,retryOnly:true,lastErrorCode:null});
    job.message='Retrying only failed websites. Successful rows and Maps results are retained.';
    await save(jobs);await chrome.alarms.create(ALARM,{periodInMinutes:0.5});kick(0);return {ok:true};
  }
  if(message.type==='network-help') {await chrome.tabs.create({url:chrome.runtime.getURL('network-help.html')});return {ok:true};}
  if (message.type==='cancel' && job?.id===message.id) {
    job.stage='cancelled';job.message='Stopped. Collected results are available.';
    await closeOwned(job);await save(jobs);await chrome.alarms.clear(ALARM);return {ok:true};
  }
  if (message.type==='resume' && job?.stage==='paused') {
    job.stage=job.phase==='websites'?'websites':'maps';job.navStarted=Date.now();
    job.message='Resuming saved progress…';await save(jobs);await chrome.alarms.create(ALARM,{periodInMinutes:0.5});kick(0);return {ok:true};
  }
  if (message.type==='show-tab' && job?.tabId!=null) {await chrome.tabs.update(job.tabId,{active:true});return {ok:true};}
  throw Error('Unknown action or run is no longer available.');
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if (sender.id!==chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL(''))) return false;
  serial(()=>command(message)).then(respond,error=>respond({error:error.message}));return true;
});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name===ALARM) serial(drive).catch(console.error);});
chrome.webNavigation.onErrorOccurred.addListener(details=>{
  if(details.frameId!==0 || details.url==='about:blank')return;
  serial(async()=>{
    const jobs=await load(),job=jobs[0];
    if(job?.tabId!==details.tabId || !running(job))return;
    job.navError=details.error;job.navErrorUrl=details.url;
    await save(jobs);kick();
  }).catch(console.error);
});
chrome.webNavigation.onDOMContentLoaded.addListener(details=>{
  if(details.frameId!==0 || details.url==='about:blank')return;
  serial(async()=>{
    const jobs=await load(),job=jobs[0];
    if(job?.tabId!==details.tabId || !running(job))return;
    job.domReadyAt=Date.now();job.loadedAt=job.domReadyAt;job.navError=null;
    await save(jobs);kick();
  }).catch(console.error);
});
chrome.tabs.onUpdated.addListener((id,change)=>{if(change.status==='complete') serial(async()=>{const [job]=await load();if(job?.tabId===id && running(job)) kick();}).catch(console.error);});
chrome.tabs.onRemoved.addListener(id=>serial(async()=>{
  const jobs=await load(),job=jobs[0];
  if(job?.tabId===id && (running(job)||job.stage==='paused')) {job.tabId=null;job.target=null;job.stage='paused';job.message='Scraping tab closed. Resume to open a new one.';await save(jobs);}
}).catch(console.error));
chrome.runtime.onStartup.addListener(()=>serial(async()=>{
  const jobs=await load(),job=jobs[0];
  if(running(job)) {job.stage='paused';job.message='Chrome restarted. Resume your saved run.';job.tabId=null;job.target=null;await save(jobs);}
}).catch(console.error));
chrome.runtime.onInstalled.addListener(()=>serial(async()=>{
  const [job]=await load();if(running(job)){await chrome.alarms.create(ALARM,{periodInMinutes:0.5});kick();}
}).catch(console.error));
