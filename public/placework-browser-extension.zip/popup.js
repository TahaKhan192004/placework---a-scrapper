import {csv} from './core.js';
const $=id=>document.getElementById(id);
let jobs=[],latest,polling=false;
function error(message='') {$('error').textContent=message;$('error').hidden=!message;}
async function send(message) {
  const result=await chrome.runtime.sendMessage(message);
  if (!result || result.error) throw Error(result?.error || 'The extension did not respond. Try reloading it.');
  return result;
}
async function download(job) {
  try {
    const reader=new FileReader();
    reader.onload=()=>chrome.downloads.download({url:reader.result,filename:'placework-browser-'+job.id.slice(0,8)+'.csv',saveAs:true}).catch(e=>error(e.message));
    reader.readAsDataURL(new Blob([csv(job.rows)],{type:'text/csv;charset=utf-8'}));
  } catch(e) {error(e.message);}
}
async function refresh() {
  if(polling)return;polling=true;
  try {
    ({jobs}=await send({type:'list'}));latest=jobs[0];
    const busy=latest && ['maps','websites','paused'].includes(latest.stage);
    $('start').disabled=!!busy;$('start-label').textContent=busy?'Run in progress':'Find & enrich places';
    $('current').hidden=!latest;
    if(latest) {
      $('job-query').textContent=latest.query;$('stage').textContent=latest.stage;$('current').dataset.stage=latest.stage;
      $('message').textContent=latest.message;
      $('places').textContent=latest.rows.length;
      $('enriched').textContent=latest.rows.filter(r=>r.website_status==='success').length;
      $('emails').textContent=new Set(latest.rows.flatMap(r=>r.emails || [])).size;
      if(latest.stage==='maps')$('progress').removeAttribute('value');
      else $('progress').value=latest.rows.length?latest.processed/latest.rows.length*100:0;
      $('download').disabled=!latest.rows.length;$('download').textContent=busy?'Partial CSV':'Download CSV';
      $('cancel').hidden=!busy;$('resume').hidden=latest.stage!=='paused';$('show-tab').hidden=!busy;
      const failed=latest.rows.filter(r=>r.website_status==='failed' && r.website).length;
      $('retry-failed').hidden=!!busy || !failed;
      $('retry-failed').textContent=`Retry failed websites (${failed})`;
      $('network-help').hidden=!failed;
      const phase={maps:0,websites:1,complete:3}[latest.stage]??-1;
      ['maps','websites','export'].forEach((s,i)=>$('step-'+s).dataset.state=phase>i?'done':phase===i?'active':'pending');
    }
    $('history').hidden=jobs.length<2;$('runs').replaceChildren();
    for(const job of jobs.slice(1)) {
      const row=document.createElement('div');row.className='run';
      const label=document.createElement('div'),title=document.createElement('span'),meta=document.createElement('span'),button=document.createElement('button');
      title.className='run-title';title.textContent=job.query;
      meta.className='run-meta';meta.textContent=`${job.rows.length} places · ${job.stage}`;
      button.textContent='CSV';button.disabled=!job.rows.length;button.onclick=()=>download(job);
      label.append(title,meta);row.append(label,button);$('runs').append(row);
    }
  } catch(e) {error(e.message);} finally {polling=false;}
}
$('search').addEventListener('submit',async event=>{
  event.preventDefault();error();$('start').disabled=true;
  try {await send({type:'start',query:$('query').value,limit:Number($('limit').value)});await refresh();}
  catch(e){error(e.message);$('start').disabled=false;}
});
$('download').onclick=()=>latest && download(latest);
for(const [id,type] of [['cancel','cancel'],['resume','resume'],['show-tab','show-tab'],['retry-failed','retry-failed'],['network-help','network-help']]) $(id).onclick=async()=>{
  try {await send({type,id:latest?.id});error();await refresh();}catch(e){error(e.message);}
};
refresh();setInterval(refresh,2000);
