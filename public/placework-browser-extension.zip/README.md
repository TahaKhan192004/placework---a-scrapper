# Placework Browser Edition

A separate Chrome-only edition. No Python, local helper, hosted backend, API key, or account. The existing Python edition is preserved in `chrome-extension` and `placework-python-extension.zip`.

## Install this development build

1. Extract `placework-browser-extension.zip` into a permanent folder.
2. Open `chrome://extensions`, enable Developer mode, choose Load unpacked, and select that folder (the one containing manifest.json).
3. Pin **Placework Browser Edition**, enter a Maps query and a limit from 1 to 200, and start.

For one-click installation by nontechnical users, this edition still needs Chrome Web Store publication and review. This ZIP is not a published store listing. No terminal commands are needed to use this edition.

## Background behavior

One inactive scraping tab at a time. You can close the popup and switch tabs. Keep Chrome running and the scraping tab open. The extension never reads other tabs and only closes tabs it created. Clicking Open scraping tab intentionally brings that tab forward.

Each discovery, place, and website page is checkpointed in Chrome local storage. An alarm wakes Chrome's built-in extension worker after suspension; it does not depend on an always-running process. Browser restarts and manually closed scraping tabs pause the run. Resume continues saved progress; Stop retains partial results. Chrome may throttle inactive pages, so progress can slow when the browser is minimized or the computer sleeps.

Maps may return fewer than the limit. Results are deduplicated by Maps entity ID. Each business loads in a separate document to avoid mixing adjacent places. Website enrichment reads the rendered landing page and up to four linked contact/about/team/location pages. Failed Maps rows and website fetch errors are retained in the CSV. Access challenges are not bypassed; Maps challenges pause for user attention.

## Permissions and privacy

Version 1.1.0 retries temporary website connection failures twice and includes an explicit `website_error_code` in CSV exports. After a run, **Retry failed websites** rechecks failed sites while preserving successful rows and Maps results. It does not repeat the Maps search. The network-help button explains errors and opens Chrome's security settings on request. Persistent DNS failures require a working Chrome/system resolver; the extension cannot change DNS settings itself or guarantee access to every website.

The `webNavigation` permission captures navigation failures and document readiness for the extension's own scraping tab, so Chrome error pages are reported as connection errors instead of extraction errors.

The extension uses tabs/scripting to read its own scraping tab, storage for jobs, alarms for resumable scheduling, and downloads for CSV. HTTP/HTTPS host permissions are needed because businesses link to arbitrary websites. It does not scan unrelated tabs, upload results, or contact a backend. Scraping uses normal Chrome browsing, so websites may receive your existing cookies for those domains. Up to ten runs are kept locally; removing the extension removes its stored jobs.

This is a JavaScript port, not an embedded Python runtime. Phone/email/social/structured-address extraction is included. Published decision-maker records come from structured page data; revenue is only extracted when explicitly published. It does not guarantee the same extraction coverage as the Python edition, which has different fetching and enrichment fallbacks.

## Platform references

The coordinator follows Chrome's [service-worker lifecycle](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle) and [alarms API](https://developer.chrome.com/docs/extensions/reference/api/alarms): state is saved rather than relying on a permanent background worker.
