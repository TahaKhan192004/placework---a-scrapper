document.getElementById('settings').onclick=()=>chrome.tabs.create({url:'chrome://settings/security'});
