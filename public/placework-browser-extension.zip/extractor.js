/* Executed only in the tab created and owned by this extension. */
(() => {
  const text = selector => document.querySelector(selector)?.textContent?.trim() || '';
  const attr = (selector, name) => document.querySelector(selector)?.getAttribute(name) || '';
  const blocked = () => /just a moment|access denied|attention required|verify you are human|security verification/i.test(document.title) || /\/sorry\/|\/sgcaptcha\/|\/captcha\//i.test(location.pathname) || !!document.querySelector('form[action*="/sorry/"], #captcha-form');
  function discover() {
    if (blocked() || location.hostname === 'consent.google.com') return {blocked:true};
    const links = [...document.querySelectorAll('a[href*="/maps/place/"]')].map(a => a.href);
    const feed = document.querySelector('[role="feed"]');
    if (feed) feed.scrollBy(0, feed.scrollHeight);
    return {links, feed:!!feed, single:!!document.querySelector('h1.DUwDvf'), url:location.href};
  }
  function place() {
    if (blocked()) return {blocked:true};
    const name = text('h1.DUwDvf');
    if (!name) return {waiting:true};
    const header = document.querySelector('div.F7nice');
    const labels = [...(header?.querySelectorAll('[aria-label]') || [])].map(e => e.getAttribute('aria-label')).join(' ');
    const reviews = (labels + ' ' + (header?.textContent || '')).match(/([\d,]+)\s+reviews|\(([\d,]+)\)/i);
    const hours = [...document.querySelectorAll('button[data-value][aria-label*="Copy open hours"]')].map(e => e.getAttribute('data-value'));
    if (hours.length < 7 && !document.documentElement.dataset.placeworkHours) {
      document.documentElement.dataset.placeworkHours = '1';
      document.querySelector('[aria-label="Show open hours for the week"]')?.click();
      return {waiting:true};
    }
    return {row:{name,
      address:text('[data-item-id="address"] .fontBodyMedium') || attr('[data-item-id="address"]','aria-label').replace(/^Address:\s*/i,''),
      phone:attr('[data-item-id^="phone:tel:"]','data-item-id').replace('phone:tel:',''),
      website:document.querySelector('a[data-item-id="authority"]')?.href || '',
      rating:text('div.F7nice span[aria-hidden="true"]'), reviews_count:(reviews?.[1] || reviews?.[2] || '').replaceAll(',',''),
      category:text('button.DkEaL'), hours:[...new Set(hours)].join('; '), description:text('.WeS02d .PYvSYb'), maps_status:'success',maps_error:''}};
  }
  function contact() {
    if (blocked()) return {blocked:true};
    if (/chrome-error:|chromewebdata/.test(location.href) || document.querySelector('#main-frame-error')) return {error:'Chrome could not load this page.'};
    const title = document.title.trim();
    if (/^(404|403|page not found|not found|forbidden)\b/i.test(title)) return {error:title};
    const root = document.body?.cloneNode(true);
    if (!root) return {waiting:true};
    root.querySelectorAll('script,style,noscript,svg').forEach(n => n.remove());
    const visible = root.innerText || root.textContent || '';
    const html = document.documentElement.outerHTML;
    const links = [...document.querySelectorAll('a[href]')].map(a => ({url:a.href,label:a.textContent.trim()}));
    const out = {emails:[],website_phones:[],website_addresses:[],facebook:[],linkedin:[],instagram:[],youtube:[],threads:[],decision_makers:[],revenue:[],pages_scraped:[location.href]};
    const addEmail = s => {
      s = s.replace(/^mailto:/i,'').split('?')[0].trim().toLowerCase();
      if (/^[\w.!#$%&'*+/=?^`{|}~-]+@[\w.-]+\.[a-z]{2,}$/i.test(s) && !/example\.com|yourdomain|sentry|wixpress/.test(s) && !/\.(png|jpg|jpeg|webp|svg)$/i.test(s)) out.emails.push(s);
    };
    (html.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || []).forEach(addEmail);
    document.querySelectorAll('[data-cfemail]').forEach(e => {
      try { const b=e.dataset.cfemail.match(/../g).map(x=>parseInt(x,16)); addEmail(String.fromCharCode(...b.slice(1).map(x=>x^b[0]))); } catch {}
    });
    const addPhone = raw => {
      let s=raw.replace(/^tel:/i,'').split(';')[0].trim();
      if (!/^\+?[\d\s().-]+$/.test(s)) return;
      let digits=s.replace(/\D/g,'');
      if (digits.startsWith('00971')) digits=digits.slice(2);
      if (digits.startsWith('9710')) digits='971'+digits.slice(4);
      if (digits.startsWith('971')) { if (![11,12].includes(digits.length)) return; s='+'+digits; }
      if (digits.length >= 7 && digits.length <= 15 && new Set(digits).size > 2) out.website_phones.push(s);
    };
    const social = raw => {
      try {
        const u=new URL(raw), host=u.hostname.toLowerCase().replace(/^www\./,''), path=u.pathname.replace(/\/$/,'');
        if (!path || /\/(share|sharer|intent|login|plugins|privacy|terms)(\/|\.|$)/i.test(path)) return;
        let platform = host==='facebook.com' || host==='m.facebook.com' ? 'facebook' : host==='instagram.com' ? 'instagram' : /(^|\.)linkedin\.com$/.test(host) ? 'linkedin' : host==='youtube.com' || host==='m.youtube.com' ? 'youtube' : /^threads\.(com|net)$/.test(host) ? 'threads' : null;
        if (!platform) return;
        if (platform==='instagram' && /^\/(p|reel|reels|stories|explore|accounts)\//.test(path)) return;
        if (platform==='youtube' && /^\/(watch|shorts|embed|playlist)(\/|$)/.test(path)) return;
        const id=u.searchParams.get('id');
        u.search=''; u.hash=''; u.pathname=path;
        if (platform==='facebook' && path==='/profile.php') { if (!/^\d+$/.test(id || '')) return; u.searchParams.set('id',id); }
        out[platform].push(u.href.replace(/\/$/,''));
      } catch {}
    };
    links.forEach(({url}) => { if (/^mailto:/i.test(url)) addEmail(decodeURIComponent(url)); else if (/^tel:/i.test(url)) addPhone(decodeURIComponent(url)); else social(url); });
    (visible.match(/\+\d[\d ().-]{6,23}\d/g) || []).forEach(addPhone);
    const address = value => {
      if (typeof value === 'string') return value.trim().slice(0,350);
      if (!value || typeof value !== 'object') return '';
      return ['streetAddress','addressLocality','addressRegion','postalCode','addressCountry'].map(k => typeof value[k]==='object' ? value[k]?.name : value[k]).filter(Boolean).join(', ');
    };
    function walk(node, depth=0) {
      if (!node || typeof node !== 'object' || depth>15) return;
      if (node.address) {const a=address(node.address);if (a) out.website_addresses.push(a);}
      if (node.email) addEmail(String(node.email));
      if (node.telephone) addPhone(String(node.telephone));
      for (const u of [].concat(node.sameAs || [])) if (typeof u==='string') social(u);
      if (node['@type']==='Person' && node.name && node.jobTitle && /founder|owner|chief|director|president|manager/i.test(node.jobTitle)) out.decision_makers.push({name:String(node.name),title:String(node.jobTitle),source_url:location.href});
      Object.values(node).forEach(v => { if (typeof v==='object') walk(v,depth+1); });
    }
    document.querySelectorAll('script[type="application/ld+json"]').forEach(s => {try {walk(JSON.parse(s.textContent));} catch {}});
    document.querySelectorAll('address').forEach(e => { const a=e.innerText?.replace(/\s+/g,' ').trim(); if (a && a.length <350) out.website_addresses.push(a); });
    out.revenue = (visible.match(/\b(?:annual\s+)?revenue\s*(?:of|is|:)?\s*[$£€]\s*\d[\d,.]*\s*(?:million|billion|thousand|[kmb])?\b/gi) || []).slice(0,10);
    for (const key of Object.keys(out)) if (key!=='decision_makers') out[key]=[...new Set(out[key])].slice(0,100);
    const base=new URL(location.href);
    const candidates=links.filter(l => {try {const u=new URL(l.url);return u.origin===base.origin && /contact|about|team|location/i.test(u.pathname+' '+l.label) && !/\.(pdf|png|jpg|zip)$/i.test(u.pathname);} catch {return false;}}).map(l=>l.url.split('#')[0]);
    return {row:out, links:[...new Set(candidates)].slice(0,4), url:location.href};
  }
  globalThis.PlaceworkExtractor = {discover,place,contact};
})();
