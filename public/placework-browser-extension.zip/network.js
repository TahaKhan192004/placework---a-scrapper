// Network classification is separate from contact extraction: an error document
// tells us that this browser failed to connect, not that a business is offline.
export function networkIssue(raw='') {
  const code=raw.match(/(?:net::)?ERR_[A-Z_]+/)?.[0]?.replace(/^net::/,'') || (/showing error page|could not load/i.test(raw)?'ERR_BROWSER_ERROR_PAGE':'ERR_EXTRACTION');
  const descriptions={
    ERR_NAME_NOT_RESOLVED:'Chrome could not resolve the website address. Check Secure DNS in Chrome, then retry failed websites.',
    ERR_INTERNET_DISCONNECTED:'Chrome is offline. Reconnect and retry failed websites.',
    ERR_CONNECTION_TIMED_OUT:'The website connection timed out.',
    ERR_TIMED_OUT:'The website took too long to load.',
    ERR_CONNECTION_RESET:'The website connection was reset.',
    ERR_CONNECTION_CLOSED:'The website closed the connection.',
    ERR_CONNECTION_REFUSED:'The connection was refused.',
    ERR_BLOCKED_BY_CLIENT:'A browser setting or another extension blocked the request.',
    ERR_BROWSER_ERROR_PAGE:'Chrome displayed a network error page before the scraper could read the site.'
  };
  const retryable=['ERR_NAME_NOT_RESOLVED','ERR_CONNECTION_TIMED_OUT','ERR_TIMED_OUT','ERR_CONNECTION_RESET','ERR_CONNECTION_CLOSED','ERR_CONNECTION_REFUSED','ERR_NETWORK_CHANGED','ERR_BROWSER_ERROR_PAGE','ERR_ABORTED'].includes(code);
  const message=descriptions[code] || (code.startsWith('ERR_CERT_')?'Chrome rejected the website certificate. Certificate warnings are not bypassed.':raw || 'The page could not be extracted.');
  return {code,message,retryable};
}
